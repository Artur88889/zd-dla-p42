using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace WinFormsApp8
{
    public partial class Form1 : Form
    {
        private CurrencyCore _server = new CurrencyCore();

        public Form1()
        {
            InitializeComponent();

            _server.OnLog += (msg) => this.Invoke((MethodInvoker)delegate
            {
                listBox1.Items.Add(msg);
                listBox1.SelectedIndex = listBox1.Items.Count - 1;
            });
        }

        private async void btnStart_Click(object sender, EventArgs e)
        {
            try
            {
                string[] auth = passwordLogin.Text.Split(':');
                if (auth.Length == 2)
                {
                    _server.Users.Clear();
                    _server.Users.Add(auth[0].Trim(), auth[1].Trim());
                }

                _server.MaxClients = (int)MaxClients.Value;
                _server.MaxRequests = (int)MaxRequests.Value;

                await _server.StartServer(9999);
            }
            catch (Exception ex)
            {
                MessageBox.Show("������ �������: " + ex.Message);
            }
        }

        private void MaxClients_ValueChanged(object sender, EventArgs e)
        {
            _server.MaxClients = (int)MaxClients.Value; //
        }

        private void MaxRequests_ValueChanged(object sender, EventArgs e)
        {
            _server.MaxRequests = (int)MaxRequests.Value; //
        }

        private void passwordLogin_TextChanged(object sender, EventArgs e)
        {
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
        }

        private async void btnStart_Click1(object sender, EventArgs e)
        {
            _server.MaxClients = (int)MaxClients.Value;
            _server.MaxRequests = (int)MaxRequests.Value;

            string[] auth = passwordLogin.Text.Split(':');
            if (auth.Length == 2)
            {
                _server.Users.Clear();
                _server.Users.Add(auth[0].Trim(), auth[1].Trim());
            }
            else
            {
                MessageBox.Show("������ ���� �� ������ ����� ���������! (���������, admin:123)");
                return;
            }

            await _server.StartServer(9999);
        }
    }
}