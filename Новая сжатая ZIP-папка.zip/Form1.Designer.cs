﻿namespace WinFormsApp8
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            MaxClients = new NumericUpDown();
            MaxRequests = new NumericUpDown();
            passwordLogin = new TextBox();
            listBox1 = new ListBox();
            btnStart = new Button();
            ((System.ComponentModel.ISupportInitialize)MaxClients).BeginInit();
            ((System.ComponentModel.ISupportInitialize)MaxRequests).BeginInit();
            SuspendLayout();
            // 
            // MaxClients
            // 
            MaxClients.Location = new Point(12, 12);
            MaxClients.Name = "MaxClients";
            MaxClients.Size = new Size(120, 23);
            MaxClients.TabIndex = 0;
            MaxClients.ValueChanged += MaxClients_ValueChanged;
            // 
            // MaxRequests
            // 
            MaxRequests.Location = new Point(138, 12);
            MaxRequests.Name = "MaxRequests";
            MaxRequests.Size = new Size(120, 23);
            MaxRequests.TabIndex = 1;
            MaxRequests.ValueChanged += MaxRequests_ValueChanged;
            // 
            // passwordLogin
            // 
            passwordLogin.Location = new Point(305, 95);
            passwordLogin.Name = "passwordLogin";
            passwordLogin.Size = new Size(100, 23);
            passwordLogin.TabIndex = 2;
            passwordLogin.TextChanged += passwordLogin_TextChanged;
            // 
            // listBox1
            // 
            listBox1.FormattingEnabled = true;
            listBox1.ItemHeight = 15;
            listBox1.Location = new Point(444, 95);
            listBox1.Name = "listBox1";
            listBox1.Size = new Size(344, 334);
            listBox1.TabIndex = 3;
            listBox1.SelectedIndexChanged += listBox1_SelectedIndexChanged;
            // 
            // btnStart
            // 
            btnStart.Location = new Point(224, 95);
            btnStart.Name = "btnStart";
            btnStart.Size = new Size(75, 23);
            btnStart.TabIndex = 4;
            btnStart.Text = "button1";
            btnStart.UseVisualStyleBackColor = true;
            btnStart.Click += btnStart_Click1;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(btnStart);
            Controls.Add(listBox1);
            Controls.Add(passwordLogin);
            Controls.Add(MaxRequests);
            Controls.Add(MaxClients);
            Name = "Form1";
            Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)MaxClients).EndInit();
            ((System.ComponentModel.ISupportInitialize)MaxRequests).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private NumericUpDown MaxClients;
        private NumericUpDown MaxRequests;
        private TextBox passwordLogin;
        private ListBox listBox1;
        private Button btnStart;
    }
}
