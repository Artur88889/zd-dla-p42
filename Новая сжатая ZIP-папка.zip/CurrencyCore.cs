﻿using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;

namespace WinFormsApp8
{
    public class CurrencyCore
    {
        private TcpListener _listener;
        public bool IsRunning { get; private set; }

        public event Action<string> OnLog;

        public int MaxClients { get; set; } = 5;
        public int MaxRequests { get; set; } = 3;
        public Dictionary<string, string> Users { get; set; } = new Dictionary<string, string>();

        private int _currentClients = 0;
        private static Dictionary<string, (int count, DateTime lastReset)> _requestTracker = new Dictionary<string, (int, DateTime)>();

        public async Task StartServer(int port)
        {
            _listener = new TcpListener(IPAddress.Any, port);
            _listener.Start();
            IsRunning = true;
            OnLog?.Invoke($"Сервер запущено на порту {port}");

            while (IsRunning)
            {
                var client = await _listener.AcceptTcpClientAsync();

                if (_currentClients >= MaxClients)
                {
                    await SendImmediate(client, "Error: Server overloaded. Try later.");
                    client.Close();
                    continue;
                }

                _ = HandleClient(client);
            }
        }

        private async Task HandleClient(TcpClient client)
        {
            _currentClients++;
            string endpoint = client.Client.RemoteEndPoint.ToString();
            OnLog?.Invoke($"[{DateTime.Now}] Підключився: {endpoint}");

            using (client)
            using (var stream = client.GetStream())
            {
                byte[] buffer = new byte[1024];

                int bytes = await stream.ReadAsync(buffer, 0, buffer.Length);
                string authData = Encoding.UTF8.GetString(buffer, 0, bytes);
                var parts = authData.Split(' ');

                if (parts.Length < 2 || !Users.ContainsKey(parts[0]) || Users[parts[0]] != parts[1])
                {
                    await SendImmediate(client, "Error: Auth failed.");
                    OnLog?.Invoke($"[{DateTime.Now}] Помилка входу: {endpoint}");
                    _currentClients--;
                    return;
                }

                await SendImmediate(client, "OK");

                while (true)
                {
                    try
                    {
                        bytes = await stream.ReadAsync(buffer, 0, buffer.Length);
                        if (bytes == 0) break;

                        string request = Encoding.UTF8.GetString(buffer, 0, bytes).Trim().ToUpper();

                        if (IsLimitExceeded(endpoint))
                        {
                            await SendImmediate(client, "Error: Limit reached. Try in 1 minute.");
                            break;
                        }

                        string response = GetRate(request);
                        await SendImmediate(client, response);
                        OnLog?.Invoke($"[{DateTime.Now}] {endpoint} запитав: {request} -> {response}");
                    }
                    catch { break; }
                }
            }

            _currentClients--;
            OnLog?.Invoke($"[{DateTime.Now}] Відключився: {endpoint}");
        }

        private bool IsLimitExceeded(string ip)
        {
            if (!_requestTracker.ContainsKey(ip)) _requestTracker[ip] = (0, DateTime.Now);

            var data = _requestTracker[ip];
            if ((DateTime.Now - data.lastReset).TotalMinutes >= 1)
            {
                _requestTracker[ip] = (1, DateTime.Now);
                return false;
            }

            if (data.count >= MaxRequests) return true;

            _requestTracker[ip] = (data.count + 1, data.lastReset);
            return false;
        }

        private string GetRate(string pair)
        {
            var rates = new Dictionary<string, double> { { "USD", 1.0 }, { "EUR", 0.92 }, { "UAH", 38.5 } };
            var parts = pair.Split(' ');
            if (parts.Length != 2 || !rates.ContainsKey(parts[0]) || !rates.ContainsKey(parts[1]))
                return "Error: Invalid currency";

            double result = rates[parts[1]] / rates[parts[0]];
            return result.ToString("F4");
        }

        private async Task SendImmediate(TcpClient client, string msg)
        {
            byte[] data = Encoding.UTF8.GetBytes(msg);
            await client.GetStream().WriteAsync(data, 0, data.Length);
        }
    }
}